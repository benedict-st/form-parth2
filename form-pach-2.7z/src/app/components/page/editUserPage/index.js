import editUserPage from "./editUserPage";
export default editUserPage;
